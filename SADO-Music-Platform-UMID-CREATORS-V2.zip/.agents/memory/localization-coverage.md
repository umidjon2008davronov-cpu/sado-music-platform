---
name: Localization coverage
description: Visible UI copy must be centralized so language switching remains complete across pages and accessibility labels.
---

Keep every user-facing phrase, including section eyebrows, helper text, empty-state actions, filter labels, and range-input labels, in the translation layer rather than hard-coding it in page components.

**Why:** A first visual pass can look correct in the default language while leaving untranslated fragments and inaccessible English labels in secondary languages.

**How to apply:** When adding a page or interaction, add all visible and screen-reader copy to every supported locale before wiring the component.